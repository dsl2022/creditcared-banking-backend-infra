/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/common/index.js":
/*!*****************************!*\
  !*** ./src/common/index.js ***!
  \*****************************/
/***/ ((module) => {

eval("\n\nmodule.exports.handler = async event => {\n  console.log(\"Stream record: \", JSON.stringify(event, null, 2));\n  event.Records.forEach(record => {\n    console.log('Stream record: ', JSON.stringify(record, null, 2));\n    if (record.eventName == 'INSERT') {\n      const newImage = record.dynamodb.NewImage;\n      console.log('New item added:', JSON.stringify(newImage, null, 2));\n    } else if (record.eventName == 'MODIFY') {\n      const oldImage = record.dynamodb.OldImage;\n      const newImage = record.dynamodb.NewImage;\n      console.log('Item modification detected:');\n      console.log('Old item:', JSON.stringify(oldImage, null, 2));\n      console.log('New item:', JSON.stringify(newImage, null, 2));\n    } else if (record.eventName == 'REMOVE') {\n      const oldImage = record.dynamodb.OldImage;\n      console.log('Item removed:', JSON.stringify(oldImage, null, 2));\n    }\n  });\n  return `Successfully processed ${event.Records.length} records.`;\n};\n\n//# sourceURL=webpack://core/./src/common/index.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./src/common/index.js");
/******/ 	module.exports = __webpack_exports__;
/******/ 	
/******/ })()
;